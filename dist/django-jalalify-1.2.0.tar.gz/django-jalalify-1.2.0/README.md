# django-jalalify
django_jalalify is a pluggable application which provides some utilities for jalali solar calendar for your Django projects.

## Quick start
1. Add `"django_jalalify"` to your `INSTALLED_APPS` setting like this::
```python
INSTALLED_APPS = [
    ...,
    "django_jalalify",
]
```
